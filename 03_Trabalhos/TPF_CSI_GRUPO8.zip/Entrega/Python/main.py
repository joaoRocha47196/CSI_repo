from simulation import Simulation
from window_simulation import WindowSimulation

simulation = Simulation()
window_simulation = WindowSimulation(simulation)




